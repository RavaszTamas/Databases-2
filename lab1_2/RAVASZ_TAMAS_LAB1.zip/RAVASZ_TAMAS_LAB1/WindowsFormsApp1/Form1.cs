﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=TAMAS-PC\\SQLEXPRESS; Initial Catalog=laboratory;" +
        "Integrated Security=true";
        DataSet dset;
        SqlDataAdapter daEmployees, daConstructionProjects;

        DataRelation dataRelationProjectsEmployees;
        SqlConnection conn;
        public Form1()
        {
            InitializeComponent();

            //SQLConnection

            conn = new SqlConnection(connectionString);

            conn.Open();
            //SQLCommand

            string queryConstructionSelect = "SELECT * FROM ConstructionProjects";
            string queryEmployeesSelect = "SELECT * FROM Employees";

            //SqlCommand cmd = new SqlCommand(queryConstructionSelect, conn);

            daConstructionProjects = new SqlDataAdapter(queryConstructionSelect, conn);
            daEmployees = new SqlDataAdapter(queryEmployeesSelect, conn);

            dset = new DataSet();

            daConstructionProjects.Fill(dset, "constructionprojects");
            daEmployees.Fill(dset, "employees");

            DataRelation dataRelationProjectsEmployees = new DataRelation("FK_Projects_Employees",
            dset.Tables["constructionprojects"].Columns["CID"],
            dset.Tables["employees"].Columns["CID"]);

            dset.Relations.Add(dataRelationProjectsEmployees);

            BindingSource bsProjects = new BindingSource();
            bsProjects.DataSource = dset;
            bsProjects.DataMember = "constructionprojects";

            BindingSource bsEmployees = new BindingSource();
            bsEmployees.DataSource = bsProjects;
            bsEmployees.DataMember = "FK_Projects_Employees";

            parentTable.DataSource = bsProjects;
            childTable.DataSource = bsEmployees;

            parentTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            childTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            conn.Close();


        }

        private void updateButtonClick(object sender, EventArgs e)
        {
            conn.Open();

            string queryConstructionSelect = "SELECT * FROM ConstructionProjects";
            string queryEmployeesSelect = "SELECT * FROM Employees";


            daConstructionProjects = new SqlDataAdapter(queryConstructionSelect, conn);
            daEmployees = new SqlDataAdapter(queryEmployeesSelect, conn);


            SqlCommandBuilder cb = new SqlCommandBuilder(daEmployees);
            daEmployees.UpdateCommand = cb.GetUpdateCommand();

            daEmployees.Update(dset, "Employees");

            conn.Close();

        }
    }
}
